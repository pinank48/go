package main

import (
	"errors"
	"fmt"

	domain "customerapp/domain"
	"customerapp/mapstore"
)

type CustomerController struct {
	store domain.CustomerStore // CustomerStore value
}

func (custom CustomerController) Add(c domain.Customer) {
	err := custom.store.Create(c)
	if err != nil {
		fmt.Println("Error", err)
		return
	}

	fmt.Println("New Customer has been created")
}
func (custom CustomerController) Update(id string, c domain.Customer) {
	err := custom.store.Update(id, c)
	if err != nil {
		fmt.Println("Error", err)
		return
	}
	fmt.Println(" Customer has been updated")
}
func (custom CustomerController) Delete(c string) {
	err := custom.store.Delete(c)
	if err != nil {
		fmt.Println("Error", err)
		return
	}

}
func (custom CustomerController) GetById(c string) {
	cust, err := custom.store.GetById(c)
	if err != nil {
		fmt.Println("Error", err)
		return
	}
	fmt.Println("customer by Id", cust)
}

func (custom CustomerController) GetAll() {
	cust, err := custom.store.GetAll()
	if err != nil {
		errors.New("sGet all error")

	}
	fmt.Println("details", cust)
}
func main() {

	controller := CustomerController{
		store: mapstore.NewMapStore(),
	}

	customer := domain.Customer{
		ID:    "1",
		Name:  "abc",
		Email: "qbc@abc.com",
	}

	customer1 := domain.Customer{
		ID:    "2",
		Name:  "mnq",
		Email: "mnq@abc.com",
	}
	customer2 := domain.Customer{
		ID:    "3",
		Name:  "qwe",
		Email: "qwe@abc.com",
	}

	controller.Add(customer)
	controller.Add(customer1)
	controller.Add(customer2)
	controller.Update("1", customer1)
	controller.Delete("2")
	controller.GetById("3")
	controller.GetAll()

}
