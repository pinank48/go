package mapstore

import (
	"errors"
	"fmt"

	"customerapp/domain"
)

type MapStore struct {
	store map[string]domain.Customer
}

func NewMapStore() *MapStore {
	return &MapStore{store: make(map[string]domain.Customer)}
}

func (m *MapStore) Create(c domain.Customer) error {
	if _, Ok := m.store[c.ID]; Ok {
		fmt.Println("record exist")
		return nil
	}
	m.store[c.ID] = c
	fmt.Println("created")
	return nil
}

func (m *MapStore) Update(k string, c domain.Customer) error {
	if _, Ok := m.store[k]; !Ok {
		fmt.Println("record doesnot exist")
		return nil
	}
	m.store[c.ID] = c
	fmt.Println("updated")
	return nil
}
func (m *MapStore) Delete(k string) error {
	if _, Ok := m.store[k]; !Ok {
		fmt.Println("record doesnot exist")
		return nil
	}
	delete(m.store, k)
	fmt.Println("deleted")
	return nil
}
func (m *MapStore) GetById(k string) (domain.Customer, error) {
	i, ok := m.store[k]
	if !ok {

		return domain.Customer{}, errors.New("getbyiderror")
	}
	return i, nil
}
func (m *MapStore) GetAll() ([]domain.Customer, error) {

	var customer = make([]domain.Customer, 0, len(m.store))
	if len(m.store) == 0 {
		//errors.New("Store is empty")
		fmt.Println("store is empty")
	}
	for _, v := range m.store {
		customer = append(customer, v)
	}
	fmt.Println(customer)
	return customer, nil
}
